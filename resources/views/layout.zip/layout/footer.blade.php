<!-- footer content -->
<footer>
    <div class="pull-right">
    <img src="{{URL::to('assets/Pay-It_logo.png')}}" width="30px">
        PayIt! || by Mobile Innovation Studio
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->